
export const salesData = [
  { year: "2022", sales: 4500 },
  { year: "2023", sales: 6000 },
  { year: "2024", sales: 7500 }
];
